create definer = root@localhost view view_user_permission as
select `gibson_os`.`user_permission`.`user_id`    AS `user_id`,
       `gibson_os`.`user_permission`.`permission` AS `permission`,
       `gibson_os`.`user_permission`.`module`     AS `module`,
       `gibson_os`.`user_permission`.`task`       AS `task`,
       `gibson_os`.`user_permission`.`action`     AS `action`,
       `gibson_os`.`module`.`id`                  AS `module_id`,
       `gibson_os`.`module`.`name`                AS `module_name`,
       `gibson_os`.`task`.`id`                    AS `task_id`,
       `gibson_os`.`task`.`name`                  AS `task_name`,
       `gibson_os`.`action`.`id`                  AS `action_id`,
       `gibson_os`.`action`.`name`                AS `action_name`
from (((`gibson_os`.`user_permission` left join `gibson_os`.`module` on (`gibson_os`.`user_permission`.`module` = `gibson_os`.`module`.`name`)) left join `gibson_os`.`task` on (`gibson_os`.`task`.`module_id` = `gibson_os`.`module`.`id`))
         left join `gibson_os`.`action` on (`gibson_os`.`action`.`task_id` = `gibson_os`.`task`.`id`))
where `gibson_os`.`user_permission`.`task` = ''
  and `gibson_os`.`user_permission`.`action` = ''
union
select `gibson_os`.`user_permission`.`user_id`    AS `user_id`,
       `gibson_os`.`user_permission`.`permission` AS `permission`,
       `gibson_os`.`user_permission`.`module`     AS `module`,
       `gibson_os`.`user_permission`.`task`       AS `task`,
       `gibson_os`.`user_permission`.`action`     AS `action`,
       `gibson_os`.`module`.`id`                  AS `module_id`,
       `gibson_os`.`module`.`name`                AS `module_name`,
       `gibson_os`.`task`.`id`                    AS `task_id`,
       `gibson_os`.`task`.`name`                  AS `task_name`,
       `gibson_os`.`action`.`id`                  AS `action_id`,
       `gibson_os`.`action`.`name`                AS `action_name`
from (((`gibson_os`.`user_permission` left join `gibson_os`.`module` on (`gibson_os`.`user_permission`.`module` = `gibson_os`.`module`.`name`)) left join `gibson_os`.`task` on (
        `gibson_os`.`task`.`module_id` = `gibson_os`.`module`.`id` and
        `gibson_os`.`user_permission`.`task` = `gibson_os`.`task`.`name`))
         left join `gibson_os`.`action` on (`gibson_os`.`action`.`task_id` = `gibson_os`.`task`.`id`))
where `gibson_os`.`user_permission`.`task` <> ''
  and `gibson_os`.`user_permission`.`action` = ''
union
select `gibson_os`.`user_permission`.`user_id`    AS `user_id`,
       `gibson_os`.`user_permission`.`permission` AS `permission`,
       `gibson_os`.`user_permission`.`module`     AS `module`,
       `gibson_os`.`user_permission`.`task`       AS `task`,
       `gibson_os`.`user_permission`.`action`     AS `action`,
       `gibson_os`.`module`.`id`                  AS `module_id`,
       `gibson_os`.`module`.`name`                AS `module_name`,
       `gibson_os`.`task`.`id`                    AS `task_id`,
       `gibson_os`.`task`.`name`                  AS `task_name`,
       `gibson_os`.`action`.`id`                  AS `action_id`,
       `gibson_os`.`action`.`name`                AS `action_name`
from (((`gibson_os`.`user_permission` left join `gibson_os`.`module` on (`gibson_os`.`user_permission`.`module` = `gibson_os`.`module`.`name`)) left join `gibson_os`.`task` on (
        `gibson_os`.`task`.`module_id` = `gibson_os`.`module`.`id` and
        `gibson_os`.`user_permission`.`task` = `gibson_os`.`task`.`name`))
         left join `gibson_os`.`action` on (`gibson_os`.`action`.`task_id` = `gibson_os`.`task`.`id` and
                                            `gibson_os`.`user_permission`.`action` = `gibson_os`.`action`.`name`))
where `gibson_os`.`user_permission`.`task` <> ''
  and `gibson_os`.`user_permission`.`action` <> '';

